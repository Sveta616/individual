﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp2
{
    class Pokypatel
    {
          private string name;
        private string surname;
        private string otchestvo;
        private string address;
        private string numberCards;
        private string numberBank;

        public string Names
        {
            get { return name; }
            set { name = value; }
        }
        public string Surname
        {
            get { return surname; }
            set { surname = value; }
        }
        public string Otchestvo
        {
            get { return otchestvo; }
            set { otchestvo = value; }
        }
    
        public string Address
        {
        get { return address; }
        set { address = value; }
    }

        public string NumberCards
        {
            get
            {
                return numberCards;
            }
            set
            {
              numberCards = value;
            }
        }
        public string NumberBank
        {
            get
            {
                return numberBank;
            }
            set
            {
                numberBank = value;
            }
        }

    }
}
