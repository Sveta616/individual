﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

      
      
        private void button1_Click(object sender, EventArgs e)
        {
            Pokypatel pokypat = new Pokypatel();
            pokypat.Surname = textBox1.Text;
            pokypat.Names = textBox2.Text;
            pokypat.Otchestvo = textBox3.Text;
            pokypat.Address = textBox4.Text;
            pokypat.NumberCards = textBox5.Text;
            pokypat.NumberBank = textBox6.Text;

            listBox1.Items.Add(pokypat.Surname);
            listBox1.Items.Add(pokypat.Names);
            listBox1.Items.Add(pokypat.Otchestvo);
            listBox1.Items.Add(pokypat.Address);
            listBox1.Items.Add(pokypat.NumberCards);
            listBox1.Items.Add(pokypat.NumberBank);

          

        }
    }
}

